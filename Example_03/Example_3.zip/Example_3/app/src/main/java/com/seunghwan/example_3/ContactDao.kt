package com.seunghwan.example_3

import androidx.lifecycle.LiveData
import androidx.room.*

interface ContactDao {//DAO : Data Access Object!!
    @Query("SELECT * FROM contact ORDER BY name ASC")
    fun getAll(): LiveData<List<Contact>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(contact: Contact)

    @Delete
    fun delete(contact: Contact)
}